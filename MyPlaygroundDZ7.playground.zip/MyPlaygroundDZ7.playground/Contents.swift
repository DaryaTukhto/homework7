 /*Есть автомобиль.
 
 У автомобиля есть свои поля и методы.
 Добавить ошибки в виде перечисления, например (автомобиль заблокирован, отсутствует топливо, сел аккумулятор, открыта дверь и т.д.)
 
 Нужно сделать ряд сценариев из повседневной жизни, например:
 
 1. Нужно поехать с магазин.
 - разблокировать машину
 - открыть дверь
 - закрыть дверь (уже сели)
 - включить зажигание
 - завести автомобиль
 - проехать определенное кол-во км
 - заглушить
 - открыть дверь
 - закрыть дверь
 - заблокировать
 
 Иметь ввиду, что не все метода кидают ошибки (загрузить автомобиль можно всегда. В нормальных ситуациях!)
 
 Минимум один нормальный сценарий и два с ошибкой. Сценарии могут быть свои, это был просто пример.
 Пример ошибочного сценария:
 
 - разблокировать
 - открыть дверь
 - закрыть дверь
 - включить зажигание -> Ошибка. Сел аккумулятор
 
 Обработка ошибок должна быть через do-catch.
 Ошибки должны обрабатываться через разные ветки do-catch, а не switch внутри одного catch.
 
 Это задание должно быть залито на Github.com.
 Ссылку на него нужно кинуть в личку преподавателю.
*/
 
 class Mashine {
    var mashine: Mashine
    var isOpen: Bool = true
    var isDoorOpen: Bool = true
    var startEngine: Bool = true
    var km: Int = 0
    var block: Bool = true
    
    
    
//    init(mashine: Mashine, km: Int = 100){
//        self.mashine = mashine
//        self.km = km
//    }
    
    enum MashineError: Error {
        case alreadyOpened
        case isBlocked
        case noDiesel
        case noEnergyInAccumulator
      
    }
    
    func unlock() throws {
        guard !isOpen else {
            throw MashineError.alreadyOpened
        }
        
        isOpen = true
    }
    
    func openDoor() throws {
        guard isOpen else {
            throw MashineError.isBlocked
        }
        isDoorOpen = true
    }
    
    
    func start() throws {
        guard startEngine else {
            throw MashineError.noEnergyInAccumulator
        }
        startEngine = true
    }
    
    func kilometers()  {
        km -= Int.random(in: 1...100)
        if km == 0 {
            MashineError.noDiesel
        }
    }
    
    

    
    
    func goToTheShop() {
       let car = Mashine() //пыталась сделать как и на уроке, но не могу понять где ошибка
        
        do {
            try goToTheShop(mashine: car)
        } catch MashineError.alreadyOpened {
            print("Car is open")
        } catch MashineError.isBlocked {
            print("Car is Blocked")
        } catch MashineError.noEnergyInAccumulator {
            print("No energy in Accumulator")
        } catch MashineError.noDiesel {
            print("No diesel")
        
    }
    
    }
   
 }


 
